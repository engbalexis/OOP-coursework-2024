/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flowControl;

/**
 *
 * @author VU-Smartboard-01
 */
import java.util.Scanner;
public class switch_flow {
    
    public static void main(String [] args){
        Scanner x = new Scanner(System.in);
        System.out.println("Enter the month of your birth");
        int month =x.nextInt();
        switch(month){
            case 1:
                System.out.println("You were born in Jan");
                break;
            
           case 2:
                System.out.println("You were born in Feb");
                break;
                
           case 3:
                System.out.println("You were born in March");
                break;
                
                
            default:
                System.out.println("You entered a wrong value");
                break;
            
        }
    }
    
}
