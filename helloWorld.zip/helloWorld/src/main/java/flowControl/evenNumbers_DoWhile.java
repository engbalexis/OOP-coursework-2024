/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flowControl;

/**
 *
 * @author VU-Smartboard-01
 */
public class evenNumbers_DoWhile {
    public static void main(String [] args){
        int count =1;
        do {
            if(count%2==0){
               System.out.println(count);
            }
            count++;
        } 
        while(count<=25);
    }
    
}
