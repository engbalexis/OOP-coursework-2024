/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flowControl;
import java.util.*;

/**
 *
 * @author VU-Smartboard-01
 */
public class checkResult {
    public static void main(String [] args){
        Scanner save = new Scanner(System.in);
        System.out.println("Enter your name please..?");
        String Name = save.nextLine();
        String name =Name.toUpperCase();
        
        System.out.println("Enter your Age please..?");
        int age = save.nextInt();
        
        System.out.println("Enter marks for ENG?");
        double eng = save.nextDouble();
        
        System.out.println("Enter marks for MATH?");
        double math = save.nextDouble();
        
        double average = (eng +math)/2;
                
        if(average>=90){            
            System.out.println(name + " aged " +age + " got " + average + " which is  A");
        }
        else if(average>=80){            
            System.out.println(name + " aged " +age + " got " + average + " which is  B");
        }
        
         else if(average>=70){            
            System.out.println(name + " aged " +age + " got " + average + " which is  C");
        }
         
          else if(average>=60){            
            System.out.println(name + " aged " +age + " got " + average + " which is  D");
        }
         else if(average>=50){            
            System.out.println(name + " aged " +age + " got " + average + " which is  O");
        }       
        
        else{
            System.out.println(name + " aged " +age + " got " + average +"whis an F");
        }
    }
    
    
}
