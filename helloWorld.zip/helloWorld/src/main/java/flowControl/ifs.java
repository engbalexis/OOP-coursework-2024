/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flowControl;

/**
 *
 * @author VU-Smartboard-01
 */
public class ifs {
    public static final double PI = 3.142;
    public static void main(String [ ] args){
        int count  = 8, total=0;
        
        if(count>=10){
            System.out.println(total);
        }
        else{
            total =total+5;
            System.out.println(total);
        }
        
        Boolean isEven =true;
        System.out.println(!isEven);
        
        
    }
    
    
    
}
