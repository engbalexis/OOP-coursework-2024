/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flowControl;

/**
 *
 * @author VU-Smartboard-01
 */
import java.util.Scanner;
public class ternary_operator {
      
    public static void main(String [] args){
        Scanner x = new Scanner(System.in);
        System.out.println("Enter your age");
        int age =x.nextInt();
        
        String name = (age>18)?"You are old pay rent":"Too young to leave home";
        
        System.out.println(name);
    
}
    
}
