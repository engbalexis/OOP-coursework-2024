/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.helloworld;

/**
 *
 * @author VU-Smartboard-01
 */
public class vars {
    public static void main(String [] args){
        
        //declaring a variables
        int age;
        //initializing variables
        age = 20;
        String Name ="Alex";
        System.out.println("I'm " + Name + " and am aged" +age + "\tyears old");
    
    }
    
}
