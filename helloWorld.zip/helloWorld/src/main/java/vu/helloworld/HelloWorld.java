/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.helloworld;

/**
 *
 * @author VU-Smartboard-01
 */
public class HelloWorld { //opening cury bracket

    public static void main(String[] args) { //main class starting here
       System.out.println("Hello World");
        
        
        
        
        
        
    }
} // closing cury bracket
