/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.helloworld;

/**
 *
 * @author VU-Smartboard-01
 */
import java.util.Scanner;
public class oper {
    public static void main(String [] args){
        Scanner s= new Scanner(System.in);
        System.out.println("Enter the value of A");
        int a = s.nextInt();
        System.out.println("Enter the value of B");
        int b = s.nextInt();
        int sum = a + b; //a,b are operand while + is an additional operator
        System.out.println(" The Sum of "+ a + " and "+ b + " is " + sum);
        
        
    }
    
}
