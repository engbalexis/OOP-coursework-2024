/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sum;

/**
 *
 * @author VU-Smartboard-01
 */
public class logic {
    public static void main(String [] args){
        ///int a =10;int b =15; int c = 20; int d = 25;
        int a =5;
        
        a %=3; //a=a+10;
        
        //System.out.println(a++);
        
        System.out.println(a);
  }
}