/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sum;

/**
 *
 * @author VU-Smartboard-01
 */
public class ind {
    public static void main(String [] args){
        ///int a =10;int b =15; int c = 20; int d = 25;
        
        int a =10, b=15 , c = 20 ,d = 25;
        
        System.out.println(a++);
        
        System.out.println(a);
        
        System.out.println(b--);
        
        System.out.println(b);
        
        System.out.println(--c);
        
        System.out.println(c);
        
        System.out.println(++d);
        
        
        System.out.println(d);
        
    }
    
}
